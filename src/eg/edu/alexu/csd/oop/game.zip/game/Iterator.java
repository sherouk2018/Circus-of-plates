package eg.edu.alexu.csd.oop.game;

public interface Iterator {
	 public boolean hasPrev();
	 public Object Prev();

}
