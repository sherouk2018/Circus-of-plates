package eg.edu.alexu.csd.oop.game;

public interface Container {
	public Iterator getIterator();

}
