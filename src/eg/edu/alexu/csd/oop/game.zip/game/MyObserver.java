package eg.edu.alexu.csd.oop.game;

public abstract class MyObserver {
	public abstract void update();

}
